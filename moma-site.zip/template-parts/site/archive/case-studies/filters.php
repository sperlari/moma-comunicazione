<?php
if (!defined('ABSPATH')) exit;

$args = wp_parse_args($args ?? [], [
  'terms' => [],
]);

$all_label = function_exists('get_field') ? (get_field('csa_filter_all_label', 'option') ?: 'Tutte') : 'Tutte';
?>
<section class="container mx-auto pb-8 lg:pb-10">
  <div class="moma-case-archive-filters flex flex-wrap gap-3" data-moma-reveal="fade-up" data-reveal-y="24" data-reveal-duration="1.05" data-reveal-delay="0.04" data-reveal-start="top 85%" data-reveal-ease="power3.out" data-reveal-once="1">
    <button type="button" class="m-btn m-btn--tag m-btn--sm m-btn--dot moma-case-filter is-active" data-case-filter="all" aria-pressed="true">
      <span class="m-btn__label"><?php echo esc_html($all_label); ?></span>
    </button>

    <?php foreach ((array) $args['terms'] as $term): ?>
      <?php if (empty($term['slug']) || empty($term['name'])) continue; ?>
      <button type="button" class="m-btn m-btn--tag m-btn--sm moma-case-filter" data-case-filter="<?php echo esc_attr($term['slug']); ?>" aria-pressed="false">
        <span class="m-btn__label"><?php echo esc_html($term['name']); ?></span>
      </button>
    <?php endforeach; ?>
  </div>
</section>
