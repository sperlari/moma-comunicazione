<?php
if (!defined('ABSPATH')) exit;

get_header();

$all_posts = get_posts([
  'post_type'      => 'case_study',
  'post_status'    => 'publish',
  'posts_per_page' => -1,
  'orderby'        => 'date',
  'order'          => 'DESC',
  'meta_query'     => [
    [
      'key'     => '_thumbnail_id',
      'compare' => 'EXISTS',
    ],
  ],
]);

if ($all_posts) {
  usort($all_posts, static function ($a, $b) {
    $a_featured = function_exists('get_field') ? (bool) get_field('cs_featured', $a->ID) : false;
    $b_featured = function_exists('get_field') ? (bool) get_field('cs_featured', $b->ID) : false;

    if ($a_featured !== $b_featured) {
      return $a_featured ? -1 : 1;
    }

    return strtotime((string) $b->post_date) <=> strtotime((string) $a->post_date);
  });
}

$statement_id = 0;
if (function_exists('get_field')) {
  $statement_rel = get_field('csa_statement_case_study', 'option');
  if (is_array($statement_rel) && !empty($statement_rel[0])) {
    $statement_id = (int) $statement_rel[0];
  } elseif (is_numeric($statement_rel)) {
    $statement_id = (int) $statement_rel;
  }
}

$statement_post = null;
if ($statement_id) {
  $statement_post = get_post($statement_id);
  if (!($statement_post instanceof WP_Post) || $statement_post->post_type !== 'case_study' || $statement_post->post_status !== 'publish' || !has_post_thumbnail($statement_post)) {
    $statement_post = null;
    $statement_id = 0;
  }
}

if (!$statement_post && !empty($all_posts)) {
  $statement_post = $all_posts[0];
  $statement_id = (int) $statement_post->ID;
}

$grid_posts = array_values(array_filter($all_posts, static function ($post_obj) use ($statement_id) {
  return (int) $post_obj->ID !== $statement_id;
}));

$term_map = [];
foreach ($grid_posts as $post_obj) {
  $terms = get_the_terms($post_obj->ID, 'case_study_category');
  if (is_wp_error($terms) || empty($terms)) continue;

  foreach ($terms as $term) {
    $slug = sanitize_title($term->slug);
    if ($slug === '' || isset($term_map[$slug])) continue;

    $term_map[$slug] = [
      'slug' => $slug,
      'name' => $term->name,
      'id'   => (int) $term->term_id,
    ];
  }
}

$filter_terms = array_values($term_map);

$cards_cursor_enabled = function_exists('get_field') ? (bool) get_field('csa_cards_cursor_enabled', 'option') : true;
$cards_cursor_image   = function_exists('get_field') ? get_field('csa_cards_cursor_image', 'option') : null;
$cards_cursor_url     = (is_array($cards_cursor_image) && !empty($cards_cursor_image['url'])) ? $cards_cursor_image['url'] : '';
$cards_cursor_attrs   = ($cards_cursor_enabled && $cards_cursor_url)
  ? sprintf(' data-cursor-scope="1" data-cursor-img="%s"', esc_url($cards_cursor_url))
  : '';

get_template_part('template-parts/site/archive/case-studies/hero');
get_template_part('template-parts/site/archive/case-studies/statement', null, [
  'statement_post'     => $statement_post,
  'card_cursor_attrs'  => $cards_cursor_attrs,
]);
get_template_part('template-parts/site/archive/case-studies/filters', null, [
  'terms' => $filter_terms,
]);
get_template_part('template-parts/site/archive/case-studies/grid', null, [
  'posts'              => $grid_posts,
  'card_cursor_attrs'  => $cards_cursor_attrs,
]);
get_template_part('template-parts/site/archive/case-studies/services-banner');

get_footer();
