import { initSmoothScroll } from "./components/smooth-scroll.js";
import { initMomaPageTransition } from "./components/moma-page-transition.js";

document.addEventListener("DOMContentLoaded", async () => {
  // 1) Smooth scroll (Lenis) — stile CLOU
  initSmoothScroll();

  // 2) Page transition
  initMomaPageTransition();

  // 3) Toggle menu (se lo usi altrove)
  const nav = document.getElementById("primary-navigation");
  const toggle = document.getElementById("primary-menu-toggle");
  if (nav && toggle) {
    toggle.addEventListener("click", (e) => {
      e.preventDefault();
      nav.classList.toggle("hidden");
    });
  }

  // 4) Init hero solo se presente
  if (document.querySelector(".moma-hero")) {
    const mod = await import("./pages/home-hero.js");
    mod.initHomeHero();
  }

  // 5) Case studies (solo se presente)
  if (document.querySelector("[data-moma-case-studies]")) {
    const mod = await import("./components/moma-case-studies-stack.js");
    mod.initMomaCaseStudies();
  }
});