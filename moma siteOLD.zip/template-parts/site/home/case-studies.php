<?php
if (!defined('ABSPATH')) exit;

$defaults = [
  'eyebrow'  => 'Esperienza, strategia, visione.',
  'title'    => 'Siamo un punto fermo.',
  'mode'     => 'auto',
  'auto_max' => 8,
];

$eyebrow  = $defaults['eyebrow'];
$title    = $defaults['title'];
$mode     = $defaults['mode'];
$auto_max = $defaults['auto_max'];
$manual   = [];

if (function_exists('get_field')) {
  $eyebrow  = get_field('home_cs_eyebrow') ?: $eyebrow;
  $title    = get_field('home_cs_title') ?: $title;
  $mode     = get_field('home_cs_mode') ?: $mode;
  $auto_max = (int) (get_field('home_cs_auto_max') ?: $auto_max);
  $manual   = get_field('home_cs_manual') ?: [];
}

$args = [
  'eyebrow' => $eyebrow,
  'title'   => $title,
  'colors'  => ['#ccc0b1', '#f38c12'],
];

// manuale: usa l’ordine scelto in ACF
if ($mode === 'manual' && !empty($manual)) {
  $posts = array_values(array_filter(array_map('get_post', (array)$manual), function ($p) {
    return ($p instanceof WP_Post) && $p->post_status === 'publish';
  }));

  if (!empty($posts)) {
    $args['posts'] = $posts;
    $args['limit'] = count($posts);
  } else {
    $args['limit'] = max(1, $auto_max);
  }
} else {
  // automatico: ordine pubblicazione (mantiene la tua logica featured + latest nel component)
  $args['limit'] = max(1, $auto_max);
}

get_template_part('template-parts/site/components/case-studies-stack', null, $args);