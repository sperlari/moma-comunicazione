<?php
if (!defined('ABSPATH')) exit;

// ACF
require_once get_theme_file_path('/inc/acf/acf-json.php');

// Fix type="module" per Vite/TailPress
require_once __DIR__ . '/assets/vite-module.php';

// CPT + media
require_once __DIR__ . '/cpt/case-studies.php';
require_once __DIR__ . '/media/image-sizes.php';
//require_once __DIR__ . '/acf/fields-case-study.php';
require_once get_theme_file_path('/inc/cpt/moma-transition-phrases.php');
require_once get_theme_file_path('/inc/rest/moma-transition-phrases.php');
require_once get_theme_file_path('/inc/integrations/moma-page-transition.php');

// Integrazioni (se ti serve mettere logiche di enqueue condizionali, ecc.)
// require_once get_theme_file_path('/inc/integrations/gsap.php');
