<?php
if (!defined('ABSPATH')) exit;

/**
 * Immagini quadrate per il “canvas” della hero.
 * Hard crop = WP taglia al centro (comportamento standard).
 */
add_action('after_setup_theme', function () {
  add_theme_support('post-thumbnails');

  // Se vuoi limitarlo al CPT: add_post_type_support('case_study', 'thumbnail');

  add_image_size('moma_cs_sq_sm', 480, 480, true);
  add_image_size('moma_cs_sq_md', 720, 720, true);
  add_image_size('moma_cs_sq_lg', 1080, 1080, true);
});
