<?php
get_header();
?>

<main id="primary" class="site-main">
  <?php get_template_part('template-parts/site/home/hero'); ?>
  <?php get_template_part('template-parts/site/home/case-studies'); ?>
</main>

<?php
get_footer();
